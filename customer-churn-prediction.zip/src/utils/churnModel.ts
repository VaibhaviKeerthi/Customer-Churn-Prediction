import { Customer, ChurnPredictionResult } from '../types';

/**
 * Calibrated Logistic Regression scoring model based on historical Telco Churn parameters.
 */
export function predictCustomerChurn(customer: Customer): ChurnPredictionResult {
  // Base intercept (log-odds of churn for a baseline customer)
  let logOdds = 0.5;

  const factors: { factor: string; impact: 'Positive' | 'Negative'; weight: number; description: string }[] = [];

  // 1. Contract Type impacts (Month-to-month is highly positive contributor to churn)
  if (customer.contract === 'Month-to-month') {
    const w = 1.8;
    logOdds += w;
    factors.push({
      factor: 'Month-to-Month Contract',
      impact: 'Positive',
      weight: w,
      description: 'Increases risk: Standard month-to-month contracts have high flexibility and zero exit friction.'
    });
  } else if (customer.contract === 'One year') {
    const w = -1.0;
    logOdds += w;
    factors.push({
      factor: 'One-year Contract Commitment',
      impact: 'Negative',
      weight: Math.abs(w),
      description: 'Decreases risk: One-year commitment creates formal structural lock-in.'
    });
  } else if (customer.contract === 'Two year') {
    const w = -2.2;
    logOdds += w;
    factors.push({
      factor: 'Two-year Contract Commitment',
      impact: 'Negative',
      weight: Math.abs(w),
      description: 'Decreases risk: Multi-year commitment acts as a strong anchor against short-term churning.'
    });
  }

  // 2. Tenure (decreasing log odds with length of account tenure)
  // Tenure of 0-3 months is highly volatile
  if (customer.tenure <= 6) {
    const w = 1.2;
    logOdds += w;
    factors.push({
      factor: 'Critical New Customer Period',
      impact: 'Positive',
      weight: w,
      description: `Increases risk: Fresh customer of only ${customer.tenure} months. Early lifecycle experience is sensitive.`
    });
  } else if (customer.tenure >= 36) {
    // Highly loyal tenure
    const w = -1.6;
    logOdds += w;
    // Cap tenure impact
    const calculatedW = Math.min(2.5, 0.04 * customer.tenure);
    logOdds -= (calculatedW - 1.6); // scale further lock in
    factors.push({
      factor: 'Established Tenure Loyalty',
      impact: 'Negative',
      weight: calculatedW,
      description: `Decreases risk: Long-term relationship of ${customer.tenure} months suggests deep system integration.`
    });
  } else {
    // Normal tenure effect
    const w = -0.04 * customer.tenure;
    logOdds += w;
    factors.push({
      factor: 'Mid-lifecycle Tenure Build-up',
      impact: 'Negative',
      weight: Math.abs(w),
      description: `Decreases risk: Stable customer relationship of ${customer.tenure} months.`
    });
  }

  // 3. Internet Service Type
  if (customer.internetService === 'Fiber optic') {
    const w = 1.4;
    logOdds += w;
    factors.push({
      factor: 'Fiber Optic Premium Plan',
      impact: 'Positive',
      weight: w,
      description: 'Increases risk: Fiber plans carry high price points, exposing customers to competitive billing comparisons.'
    });
  } else if (customer.internetService === 'DSL') {
    const w = -0.4;
    logOdds += w;
    factors.push({
      factor: 'DSL Legacy Service',
      impact: 'Negative',
      weight: Math.abs(w),
      description: 'Decreases risk: Conservative plan segments often feature low price points and stable service expectations.'
    });
  }

  // 4. Tech Support and Security
  if (customer.techSupport === 'No' && customer.internetService !== 'No') {
    const w = 0.9;
    logOdds += w;
    factors.push({
      factor: 'Lack of Tech Support Access',
      impact: 'Positive',
      weight: w,
      description: 'Increases risk: No access to premium support leaves customer vulnerable to technical roadblocks.'
    });
  } else if (customer.techSupport === 'Yes') {
    const w = -0.8;
    logOdds += w;
    factors.push({
      factor: 'Premium Technical Support enrolled',
      impact: 'Negative',
      weight: Math.abs(w),
      description: 'Decreases risk: Responsive troubleshooting assistance builds solid customer success habits.'
    });
  }

  if (customer.onlineSecurity === 'No' && customer.internetService !== 'No') {
    const w = 0.8;
    logOdds += w;
    factors.push({
      factor: 'Online Security Disabled',
      impact: 'Positive',
      weight: w,
      description: 'Increases risk: Absence of critical network protective utilities lowers switching barriers.'
    });
  } else if (customer.onlineSecurity === 'Yes') {
    const w = -0.9;
    logOdds += w;
    factors.push({
      factor: 'Enrolled in Cyber Protection Suite',
      impact: 'Negative',
      weight: Math.abs(w),
      description: 'Decreases risk: Critical data security attachment increases perceived product value and safety.'
    });
  }

  // 5. Payment Methods & Billing
  if (customer.paymentMethod === 'Electronic check') {
    const w = 0.7;
    logOdds += w;
    factors.push({
      factor: 'Manual Electronic Check Billing',
      impact: 'Positive',
      weight: w,
      description: 'Increases risk: Initiating manual check payments monthly forces highly conscious bill evaluation.'
    });
  } else if (customer.paymentMethod.includes('automatic')) {
    const w = -0.7;
    logOdds += w;
    factors.push({
      factor: 'Auto-Pay Configuration Active',
      impact: 'Negative',
      weight: Math.abs(w),
      description: 'Decreases risk: Auto-pay minimizes friction, taking transaction tasks away from daily awareness.'
    });
  }

  if (customer.paperlessBilling) {
    const w = 0.3;
    logOdds += w;
  }

  // 6. Demographics
  if (customer.seniorCitizen) {
    const w = 0.4;
    logOdds += w;
    factors.push({
      factor: 'Senior Citizen Demographics',
      impact: 'Positive',
      weight: w,
      description: 'Increases risk: High sensitivity to pricing adjustments and digital onboarding ease.'
    });
  }
  if (customer.partner || customer.dependents) {
    const w = -0.4;
    logOdds += w;
    factors.push({
      factor: 'Multi-member Household Account',
      impact: 'Negative',
      weight: Math.abs(w),
      description: 'Decreases risk: Joint family usage creates high relational coordination cost to close.'
    });
  }

  // 7. High price point penalty relative to tenure
  const priceToTenureRatio = customer.monthlyCharges / (customer.tenure + 1);
  if (priceToTenureRatio > 80) {
    const w = 0.8;
    logOdds += w;
    factors.push({
      factor: 'Disproportionate Spend Ratio',
      impact: 'Positive',
      weight: w,
      description: 'Increases risk: High monthly billing compared to structural loyalty length encourages switching.'
    });
  }

  // Calculate Sigmoid: 1 / (1 + e^-z)
  const probability = 1 / (1 + Math.exp(-logOdds));

  // Sort factor contributions by relevance
  const sortedFactors = factors.sort((a, b) => b.weight - a.weight);

  let riskCategory: 'Low' | 'Medium' | 'High' = 'Low';
  if (probability > 0.65) {
    riskCategory = 'High';
  } else if (probability > 0.3) {
    riskCategory = 'Medium';
  }

  return {
    probability: Number(probability.toFixed(3)),
    riskCategory,
    contributingFactors: sortedFactors
  };
}
