import React from 'react';

interface MetricCardProps {
  title: string;
  value: string | number;
  subtext: string;
  icon: React.ReactNode;
  trend?: {
    value: string;
    isPositive: boolean; // Positive for business health, e.g., low churn or higher charges
  };
}

export default function MetricCard({ title, value, subtext, icon, trend }: MetricCardProps) {
  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-shadow duration-300">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-slate-500 uppercase tracking-wider">{title}</span>
        <div className="p-2 bg-slate-50 rounded-lg text-slate-600">
          {icon}
        </div>
      </div>
      <div className="mt-4 flex items-baseline gap-2">
        <span className="text-3xl font-bold font-display tracking-tight text-slate-900">{value}</span>
        {trend && (
          <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
            trend.isPositive ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
          }`}>
            {trend.value}
          </span>
        )}
      </div>
      <p className="mt-1 text-xs text-slate-400">{subtext}</p>
    </div>
  );
}
