import { Customer } from '../types';
import { Sliders, RefreshCw, Layers, CheckCircle2, AlertCircle } from 'lucide-react';

interface PredictionFormProps {
  customer: Customer;
  onChangeCustomer: (updated: Customer) => void;
  onReset: () => void;
}

export default function PredictionForm({ customer, onChangeCustomer, onReset }: PredictionFormProps) {
  const updateField = (field: keyof Customer, value: any) => {
    const updated = { ...customer, [field]: value };
    // Maintain sensible totals based on changed tenure
    if (field === 'tenure' || field === 'monthlyCharges') {
      updated.totalCharges = Number((updated.tenure * updated.monthlyCharges).toFixed(2));
    }
    onChangeCustomer(updated);
  };

  // Helper lists of valid values
  const contracts = ['Month-to-month', 'One year', 'Two year'] as const;
  const internetServices = ['DSL', 'Fiber optic', 'No'] as const;
  const yesNoNoInternet = ['No', 'Yes', 'No internet service'] as const;
  const paymentMethods = [
    'Electronic check',
    'Mailed check',
    'Bank transfer (automatic)',
    'Credit card (automatic)',
  ] as const;

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
      <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-5">
        <h3 className="font-bold text-slate-800 flex items-center gap-2">
          <Sliders className="h-5 w-5 text-indigo-500" />
          What-If Playground Sandbox
        </h3>
        <button
          onClick={onReset}
          className="text-xs text-slate-400 hover:text-slate-600 flex items-center gap-1 bg-slate-50 border border-slate-100 px-2.5 py-1 rounded-md"
        >
          <RefreshCw className="h-3 w-3" /> Reset Account
        </button>
      </div>

      <div className="space-y-4 text-sm">
        {/* Name input */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Customer Name
            </label>
            <input
              type="text"
              value={customer.name}
              onChange={(e) => updateField('name', e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Reference Account ID
            </label>
            <input
              type="text"
              value={customer.id}
              onChange={(e) => updateField('id', e.target.value)}
              className="w-full px-3 py-1.5 border border-slate-200 bg-slate-50 rounded-lg text-slate-500 focus:outline-hidden font-mono text-xs"
            />
          </div>
        </div>

        {/* Contract Toggles */}
        <div>
          <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
            Contract Commitment Structure
          </label>
          <div className="grid grid-cols-3 gap-1.5 bg-slate-100/70 p-1 rounded-lg">
            {contracts.map((opt) => (
              <button
                key={opt}
                type="button"
                onClick={() => updateField('contract', opt)}
                className={`text-xs py-1.5 rounded-md font-semibold transition-all ${
                  customer.contract === opt
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
          <p className="text-[10px] text-slate-400 mt-1">
            * Long-term contracts introduce stable retention periods, decreasing customer flight.
          </p>
        </div>

        {/* Tenure Slider */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Service Tenure: <b className="text-slate-800">{customer.tenure} months</b>
            </label>
            <span className="text-[10px] text-indigo-600 font-mono font-bold">
              {customer.tenure > 36 ? 'Established (Low Risk)' : customer.tenure <= 6 ? 'New User Stage (High Volatility)' : 'Standard'}
            </span>
          </div>
          <input
            type="range"
            min="1"
            max="72"
            value={customer.tenure}
            onChange={(e) => updateField('tenure', parseInt(e.target.value))}
            className="w-full accent-indigo-600"
          />
          <div className="flex justify-between text-[10px] text-slate-400 font-mono">
            <span>1 month</span>
            <span>36 mo / Median</span>
            <span>72 mo / Max</span>
          </div>
        </div>

        {/* Internet Service Tier */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5">
              Internet Service Type
            </label>
            <div className="grid grid-cols-3 gap-1 bg-slate-100 p-1 rounded-lg">
              {internetServices.map((tier) => (
                <button
                  key={tier}
                  type="button"
                  onClick={() => {
                    const nextInternet = tier;
                    let nextSecurity = customer.onlineSecurity;
                    let nextSupport = customer.techSupport;
                    if (tier === 'No') {
                      nextSecurity = 'No internet service';
                      nextSupport = 'No internet service';
                    } else if (customer.onlineSecurity === 'No internet service') {
                      nextSecurity = 'No';
                      nextSupport = 'No';
                    }
                    const updated = {
                      ...customer,
                      internetService: nextInternet,
                      onlineSecurity: nextSecurity,
                      techSupport: nextSupport,
                    };
                    onChangeCustomer(updated);
                  }}
                  className={`text-[10px] py-1 rounded-md font-semibold ${
                    customer.internetService === tier
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  {tier}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Monthly Charge Rate (₹)
            </label>
            <div className="flex gap-2 items-center">
              <input
                type="number"
                min="199"
                max="2499"
                step="10"
                value={customer.monthlyCharges}
                onChange={(e) => updateField('monthlyCharges', parseFloat(e.target.value) || 199)}
                className="w-24 px-2 py-1 text-sm text-center border border-slate-200 rounded-lg focus:outline-hidden font-mono font-bold"
              />
              <input
                type="range"
                min="199"
                max="2499"
                step="10"
                value={customer.monthlyCharges}
                onChange={(e) => updateField('monthlyCharges', parseInt(e.target.value))}
                className="flex-1 accent-indigo-600"
              />
            </div>
          </div>
        </div>

        {/* Security & Support Sub services */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Cyber Security Shield
            </label>
            <select
              value={customer.onlineSecurity}
              disabled={customer.internetService === 'No'}
              onChange={(e) => updateField('onlineSecurity', e.target.value as any)}
              className="w-full text-xs border border-slate-200 px-2 py-1.5 bg-white rounded-lg disabled:bg-slate-50"
            >
              {yesNoNoInternet.map((opt) => (
                <option key={opt} value={opt}>
                  {opt === 'No internet service' ? 'Unavailable' : opt}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Premium Technical Support
            </label>
            <select
              value={customer.techSupport}
              disabled={customer.internetService === 'No'}
              onChange={(e) => updateField('techSupport', e.target.value as any)}
              className="w-full text-xs border border-slate-200 px-2 py-1.5 bg-white rounded-lg disabled:bg-slate-50"
            >
              {yesNoNoInternet.map((opt) => (
                <option key={opt} value={opt}>
                  {opt === 'No internet service' ? 'Unavailable' : opt}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Payment Method Billing options */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">
              Payment Clearing Channel
            </label>
            <select
              value={customer.paymentMethod}
              onChange={(e) => updateField('paymentMethod', e.target.value as any)}
              className="w-full text-xs border border-slate-200 px-2 py-1.5 bg-white rounded-lg"
            >
              {paymentMethods.map((pm) => (
                <option key={pm} value={pm}>
                  {pm}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-col justify-end space-y-2">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="senior"
                checked={customer.seniorCitizen}
                onChange={(e) => updateField('seniorCitizen', e.target.checked)}
                className="h-4 w-4 rounded-sm border-slate-300 text-indigo-600 accent-indigo-600"
              />
              <label htmlFor="senior" className="text-xs font-medium text-slate-600 selection:bg-indigo-100">
                Senior Citizen (Age 65+)
              </label>
            </div>
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="household"
                checked={customer.partner || customer.dependents}
                onChange={(e) => {
                  onChangeCustomer({
                    ...customer,
                    partner: e.target.checked,
                    dependents: e.target.checked,
                  });
                }}
                className="h-4 w-4 rounded-sm border-slate-300 text-indigo-600 accent-indigo-600"
              />
              <label htmlFor="household" className="text-xs font-medium text-slate-600 selection:bg-indigo-100">
                Partner / Family Dependents
              </label>
            </div>
          </div>
        </div>

        {/* Paperless Billing Option */}
        <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="paperless"
              checked={customer.paperlessBilling}
              onChange={(e) => updateField('paperlessBilling', e.target.checked)}
              className="h-4 w-4 rounded-sm border-slate-300 text-indigo-600 accent-indigo-600"
            />
            <label htmlFor="paperless" className="text-xs font-semibold text-slate-700 select-none">
              Paperless Digital Billing
            </label>
          </div>
          <span className="text-[10px] text-slate-400">
            {customer.paperlessBilling ? 'Digital invoices activated' : 'Physical paper invoice mailed'}
          </span>
        </div>

        {/* Quick Simulation Presets */}
        <div className="border-t border-slate-100 pt-3">
          <span className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
            What-If Scenarios Quick Presets:
          </span>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => {
                const preset: Customer = {
                  ...customer,
                  contract: 'Month-to-month',
                  tenure: 2,
                  internetService: 'Fiber optic',
                  monthlyCharges: 949.0,
                  totalCharges: 1898.0,
                  onlineSecurity: 'No',
                  techSupport: 'No',
                  paymentMethod: 'Electronic check',
                  paperlessBilling: true,
                };
                onChangeCustomer(preset);
              }}
              className="text-[10px] px-2.5 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors border border-rose-100 rounded-md font-semibold flex items-center gap-1"
            >
              🔥 Risky Profile
            </button>
            <button
              type="button"
              onClick={() => {
                const preset: Customer = {
                  ...customer,
                  contract: 'Two year',
                  tenure: 48,
                  internetService: 'DSL',
                  monthlyCharges: 499.0,
                  totalCharges: 23952.0,
                  onlineSecurity: 'Yes',
                  techSupport: 'Yes',
                  paymentMethod: 'Credit card (automatic)',
                  paperlessBilling: false,
                };
                onChangeCustomer(preset);
              }}
              className="text-[10px] px-2.5 py-1 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors border border-emerald-100 rounded-md font-semibold flex items-center gap-1"
            >
              🛡️ Locked-In Loyal
            </button>
            <button
              type="button"
              onClick={() => {
                const preset: Customer = {
                  ...customer,
                  contract: 'Month-to-month',
                  tenure: 14,
                  internetService: 'Fiber optic',
                  monthlyCharges: 849.0,
                  totalCharges: 11886.0,
                  onlineSecurity: 'No',
                  techSupport: 'No',
                  paymentMethod: 'Electronic check',
                  paperlessBilling: true,
                };
                onChangeCustomer(preset);
              }}
              className="text-[10px] px-2.5 py-1 bg-amber-50 text-amber-700 hover:bg-amber-100 transition-colors border border-amber-100 rounded-md font-semibold flex items-center gap-1"
            >
              ⚡ At-Risk (Fiber optic only)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
