import { useState, useMemo } from 'react';
import { Customer } from '../types';
import { predictCustomerChurn } from '../utils/churnModel';
import { Search, Filter, HelpCircle, ArrowRight, UserCheck, UserMinus, ShieldAlert } from 'lucide-react';

interface CustomerTableProps {
  customers: Customer[];
  selectedCustomer: Customer | null;
  onSelectCustomer: (customer: Customer) => void;
}

export default function CustomerTable({ customers, selectedCustomer, onSelectCustomer }: CustomerTableProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [contractFilter, setContractFilter] = useState<'All' | 'Month-to-month' | 'One year' | 'Two year'>('All');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Churned' | 'HighRisk'>('All');

  // Calculate quick score bounds on variables
  const customersWithScores = useMemo(() => {
    return customers.map(c => {
      const scoring = predictCustomerChurn(c);
      return {
        ...c,
        calculatedRisk: scoring.probability,
        riskCategory: scoring.riskCategory
      };
    });
  }, [customers]);

  // Combine filters
  const filteredCustomers = useMemo(() => {
    return customersWithScores.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                            c.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            c.email.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesContract = contractFilter === 'All' || c.contract === contractFilter;

      let matchesStatus = true;
      if (statusFilter === 'Active') {
        matchesStatus = !c.churn;
      } else if (statusFilter === 'Churned') {
        matchesStatus = c.churn;
      } else if (statusFilter === 'HighRisk') {
        matchesStatus = c.riskCategory === 'High' && !c.churn;
      }

      return matchesSearch && matchesContract && matchesStatus;
    });
  }, [customersWithScores, searchTerm, contractFilter, statusFilter]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col h-[580px]">
      {/* Table Header Filter Area */}
      <div className="p-4 border-b border-slate-200 space-y-3">
        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:max-w-xs">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400">
              <Search className="h-4 w-4" />
            </span>
            <input
              type="text"
              placeholder="Search by name, ID, or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1 shrink-0">
              <Filter className="h-3 w-3" /> Filters:
            </span>
            <div className="flex gap-1">
              {(['All', 'Active', 'HighRisk', 'Churned'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setStatusFilter(status)}
                  className={`text-xs px-2.5 py-1 rounded-md font-medium transition-colors ${
                    statusFilter === status 
                      ? 'bg-slate-900 text-white' 
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  {status === 'HighRisk' ? 'At Risk' : status}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Contract Specific Subtabs */}
        <div className="flex gap-1 border-t border-slate-100 pt-2 shrink-0">
          {(['All', 'Month-to-month', 'One year', 'Two year'] as const).map((contract) => (
            <button
              key={contract}
              onClick={() => setContractFilter(contract)}
              className={`text-xs px-3 py-1 border-b-2 font-medium transition-all ${
                contractFilter === contract 
                  ? 'border-indigo-600 text-indigo-600 font-semibold' 
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              {contract}
            </button>
          ))}
        </div>
      </div>

      {/* Customer Record Rows list Container */}
      <div className="overflow-y-auto flex-1">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-4 py-2.5 text-xs font-semibold text-slate-500">Customer Details</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-slate-500">Tenure & Contract</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-slate-500">Charges</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-slate-500">Risk Profile</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-slate-500 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {filteredCustomers.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-12 text-center text-slate-400 bg-slate-50/50">
                  <div className="flex flex-col items-center justify-center space-y-1">
                    <Search className="h-6 w-6 stroke-1 text-slate-300" />
                    <span className="font-medium text-slate-600">No matching accounts found</span>
                    <span className="text-xs">Try clearing search phrases or loosening criteria</span>
                  </div>
                </td>
              </tr>
            ) : (
              filteredCustomers.map((c) => {
                const isSelected = selectedCustomer?.id === c.id;
                return (
                  <tr 
                    key={c.id} 
                    onClick={() => onSelectCustomer(c)}
                    className={`cursor-pointer group hover:bg-indigo-50/20 transition-all ${
                      isSelected ? 'bg-indigo-50 border-l-4 border-l-indigo-600' : ''
                    }`}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-lg shrink-0 ${
                          c.churn 
                            ? 'bg-rose-50 text-rose-600' 
                            : c.riskCategory === 'High' 
                              ? 'bg-amber-50 text-amber-600' 
                              : 'bg-emerald-50 text-emerald-600'
                        }`}>
                          {c.churn ? (
                            <UserMinus className="h-4 w-4" />
                          ) : c.riskCategory === 'High' ? (
                            <ShieldAlert className="h-4 w-4" />
                          ) : (
                            <UserCheck className="h-4 w-4" />
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors">
                            {c.name}
                          </p>
                          <p className="text-xs text-slate-400 font-mono">{c.id} • {c.email}</p>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3">
                      <span className="text-xs bg-slate-100 text-slate-700 font-semibold px-2 py-0.5 rounded-full inline-block">
                        {c.contract}
                      </span>
                      <p className="text-xs text-slate-500 mt-1">{c.tenure} months on files</p>
                    </td>

                    <td className="px-4 py-3">
                      <p className="font-semibold text-slate-800">₹{c.monthlyCharges.toFixed(0)}/mo</p>
                      <p className="text-xs text-slate-400">Total: ₹{c.totalCharges.toFixed(0)}</p>
                    </td>

                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${
                              c.churn 
                                ? 'bg-slate-400' 
                                : c.calculatedRisk > 0.65 
                                  ? 'bg-rose-500' 
                                  : c.calculatedRisk > 0.3 
                                    ? 'bg-amber-500' 
                                    : 'bg-emerald-500'
                            }`}
                            style={{ width: `${c.churn ? 100 : c.calculatedRisk * 100}%` }}
                          />
                        </div>
                        <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded-md ${
                          c.churn 
                            ? 'bg-slate-100 text-slate-500' 
                            : c.riskCategory === 'High' 
                              ? 'bg-rose-50 text-rose-700' 
                              : c.riskCategory === 'Medium' 
                                ? 'bg-amber-50 text-amber-700' 
                                : 'bg-emerald-50 text-emerald-700'
                        }`}>
                          {c.churn ? 'Churned' : `${Math.round(c.calculatedRisk * 100)}%`}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 lowercase block font-mono mt-0.5">
                        {c.internetService} plan • security {c.onlineSecurity === 'Yes' ? 'on' : 'off'}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-right">
                      <button className="text-slate-400 hover:text-indigo-600 p-1.5 hover:bg-slate-50 rounded-lg inline-flex items-center gap-1 text-xs">
                        Sandbox <ArrowRight className="h-3 w-3" />
                      </button>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Table Footer Summary Indicator info */}
      <div className="bg-slate-50 px-4 py-3 border-t border-slate-200 text-xs text-slate-500 rounded-b-xl flex items-center justify-between">
        <span>Showing <b>{filteredCustomers.length}</b> customer accounts from historical study</span>
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-emerald-500 rounded-full inline-block" /> Low Risk (&lt;30%)</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-amber-500 rounded-full inline-block" /> Medium (31%-65%)</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-rose-500 rounded-full inline-block" /> High Risk (&gt;65%)</span>
        </div>
      </div>
    </div>
  );
}
