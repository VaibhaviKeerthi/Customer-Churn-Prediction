import { RetentionStrategy } from '../types';
import { Target, Sparkles, TrendingUp, Handshake, CornerDownRight, CheckCircle2 } from 'lucide-react';

interface AIPlaybookSectionProps {
  strategy: RetentionStrategy | null;
  loading: boolean;
  onGenerate: () => void;
  customerName: string;
}

export default function AIPlaybookSection({ strategy, loading, onGenerate, customerName }: AIPlaybookSectionProps) {
  return (
    <div className="bg-slate-900 text-white rounded-xl border border-slate-800 p-6 shadow-md transition-all duration-300 relative overflow-hidden">
      {/* Decorative gradient overlay */}
      <div className="absolute right-0 top-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-800 pb-4 mb-5 gap-3">
        <div>
          <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider font-mono">
            Gemini Core AI Playbook
          </span>
          <h3 className="font-bold text-lg text-slate-100 font-display mt-1 flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-indigo-400" />
            Retention & Save Action Plan
          </h3>
        </div>
        <button
          onClick={onGenerate}
          disabled={loading}
          className={`px-4 py-1.5 rounded-lg text-xs font-semibold select-none flex items-center gap-1.5 transition-all ${
            loading 
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
              : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-xs hover:shadow-md'
          }`}
        >
          {loading ? (
            <>
              <div className="h-3 w-3 border-2 border-slate-500 border-t-white rounded-full animate-spin" />
              Compiling...
            </>
          ) : (
            <>
              <Sparkles className="h-3.5 w-3.5" />
              Generate Retention Strategy
            </>
          )}
        </button>
      </div>

      {loading ? (
        <div className="py-12 flex flex-col items-center justify-center space-y-4">
          <div className="h-8 w-8 border-3 border-indigo-600 border-t-indigo-400 rounded-full animate-spin" />
          <div className="text-center">
            <p className="text-sm font-medium text-slate-300">Engineering mitigation strategy for {customerName}...</p>
            <p className="text-xs text-slate-500 mt-1">Applying classification attributions to Gemini-3.5-Flash model</p>
          </div>
          {/* Animated fake processing pipeline timeline */}
          <div className="w-full max-w-xs space-y-1 pt-2">
            <div className="flex justify-between text-[10px] font-mono text-slate-400">
              <span className="animate-pulse">Loading weights...</span>
              <span>78% Done</span>
            </div>
            <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
              <div className="h-full bg-indigo-500 rounded-full animate-pulse" style={{ width: '78%' }} />
            </div>
          </div>
        </div>
      ) : strategy ? (
        <div className="space-y-6">
          {/* Main Play Header details */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-850 p-4 rounded-lg border border-slate-800 col-span-2">
              <span className="text-[10px] text-slate-400 font-mono block">RECOMMENDED MITIGATION PLAY</span>
              <p className="font-bold text-base text-indigo-300 font-display mt-0.5">{strategy.recommendedPlay}</p>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">{strategy.winbackValue}</p>
            </div>

            <div className="bg-slate-850 p-4 rounded-lg border border-slate-800 flex flex-col items-center justify-center text-center">
              <span className="text-[10px] text-slate-400 font-mono">SAVE PROBABILITY</span>
              <div className="relative mt-2 flex items-center justify-center">
                {/* SVG Radial Progress */}
                <svg className="w-16 h-16 transform -rotate-90">
                  <circle cx="32" cy="32" r="28" stroke="#1e293b" strokeWidth="4" fill="transparent" />
                  <circle cx="32" cy="32" r="28" stroke="#6366f1" strokeWidth="4" fill="transparent" 
                    strokeDasharray={175} strokeDashoffset={175 - (175 * strategy.estimatedSuccessProbability) / 100}
                    strokeLinecap="round" className="transition-all duration-1000" />
                </svg>
                <span className="absolute text-sm font-bold font-mono text-indigo-200">
                  {strategy.estimatedSuccessProbability}%
                </span>
              </div>
              <p className="text-[9px] text-indigo-400 mt-2 uppercase font-semibold">High salvage potential</p>
            </div>
          </div>

          {/* Offer Details */}
          <div className="bg-gradient-to-r from-indigo-950/40 to-slate-850 p-4 rounded-lg border border-indigo-900/30">
            <div className="flex items-center gap-1.5 text-indigo-400 text-xs font-bold uppercase tracking-wider font-mono">
              <Target className="h-4 w-4 shrink-0" /> Target Contract / Service Incentives Offer:
            </div>
            <p className="text-sm font-medium mt-1 text-slate-100 pl-5 leading-relaxed">
              {strategy.offerDetails}
            </p>
          </div>

          {/* Action Step Playbook Timeline */}
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-3 font-mono">
              Execution Playbook (Account Manager Action Steps)
            </span>
            <div className="space-y-4 PL-1">
              {strategy.playbookSteps.map((step, idx) => (
                <div key={idx} className="flex gap-3 items-start">
                  <div className="w-5 h-5 rounded-full bg-indigo-500/20 text-indigo-300 font-mono text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5 border border-indigo-500/30">
                    {idx + 1}
                  </div>
                  <div>
                    <p className="text-xs text-slate-300 leading-relaxed font-sans mt-0.5">{step}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Warning driver tag labels */}
          <div className="border-t border-slate-800 pt-4 flex flex-wrap gap-2 items-center">
            <span className="text-[10px] text-slate-500 uppercase font-mono font-bold">Risk Factors Addressed:</span>
            {strategy.riskDrivers.map((driver, index) => (
              <span key={index} className="text-[9px] bg-rose-500/10 text-rose-300 font-semibold px-2 py-0.5 border border-rose-500/10 rounded-md">
                {driver}
              </span>
            ))}
          </div>
        </div>
      ) : (
        <div className="py-10 text-center border-2 border-dashed border-slate-800 rounded-lg">
          <Handshake className="h-10 w-10 text-slate-600 stroke-1 mx-auto mb-2" />
          <p className="text-sm font-semibold text-slate-300">No Save Playbook active</p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
            Click &quot;Generate Retention Strategy&quot; to prompt Gemini for a custom loyalty offer and phone script tailored to {customerName}&apos;s billing profile.
          </p>
        </div>
      )}
    </div>
  );
}
