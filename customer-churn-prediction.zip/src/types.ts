export interface Customer {
  id: string;
  name: string;
  email: string;
  gender: 'Male' | 'Female';
  seniorCitizen: boolean;
  partner: boolean;
  dependents: boolean;
  tenure: number; // in months
  phoneService: boolean;
  multipleLines: 'No' | 'Yes' | 'No phone service';
  internetService: 'DSL' | 'Fiber optic' | 'No';
  onlineSecurity: 'No' | 'Yes' | 'No internet service';
  onlineBackup: 'No' | 'Yes' | 'No internet service';
  deviceProtection: 'No' | 'Yes' | 'No internet service';
  techSupport: 'No' | 'Yes' | 'No internet service';
  streamingTV: 'No' | 'Yes' | 'No internet service';
  streamingMovies: 'No' | 'Yes' | 'No internet service';
  contract: 'Month-to-month' | 'One year' | 'Two year';
  paperlessBilling: boolean;
  paymentMethod: 'Electronic check' | 'Mailed check' | 'Bank transfer (automatic)' | 'Credit card (automatic)';
  monthlyCharges: number;
  totalCharges: number;
  churn: boolean;
}

export interface ChurnPredictionResult {
  probability: number; // 0 to 1
  riskCategory: 'Low' | 'Medium' | 'High';
  contributingFactors: {
    factor: string;
    impact: 'Positive' | 'Negative'; // Positive increases risk, Negative decreases risk
    weight: number; // relative weight/score contribution
    description: string;
  }[];
}

export interface RetentionStrategy {
  customerName: string;
  churnProbability: number;
  riskDrivers: string[];
  recommendedPlay: string;
  winbackValue: string;
  offerDetails: string;
  playbookSteps: string[];
  estimatedSuccessProbability: number;
}
