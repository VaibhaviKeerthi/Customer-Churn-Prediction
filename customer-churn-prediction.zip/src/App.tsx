import { useState, useMemo, useEffect } from 'react';
import { Customer, RetentionStrategy } from './types';
import { historicalCustomers } from './data/historicalCustomers';
import { predictCustomerChurn } from './utils/churnModel';
import MetricCard from './components/MetricCard';
import CustomerTable from './components/CustomerTable';
import PredictionForm from './components/PredictionForm';
import AIPlaybookSection from './components/AIPlaybookSection';
import {
  Users,
  TrendingUp,
  AlertTriangle,
  DollarSign,
  Fingerprint,
  PieChart as PieChartIcon,
  BrainCircuit,
  FileText,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  Info,
  Layers,
  Activity,
  FileText as FileTextIcon
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  LineChart,
  Line,
  Cell,
  PieChart,
  Pie
} from 'recharts';

export default function App() {
  const [activeTab, setActiveTab] = useState<'sandbox' | 'cohort'>('sandbox');
  const [selectedCust, setSelectedCust] = useState<Customer>(historicalCustomers[0]);
  const [strategy, setStrategy] = useState<RetentionStrategy | null>(null);
  const [strategyLoading, setStrategyLoading] = useState(false);
  const [macroInsights, setMacroInsights] = useState<string | null>(null);
  const [macroLoading, setMacroLoading] = useState(false);

  // Instantly score the sandbox customer using the logistic classifier model
  const sandboxScore = useMemo(() => {
    return predictCustomerChurn(selectedCust);
  }, [selectedCust]);

  // Reset sandbox when selected input changes or user taps reset
  const handleSelectCustomer = (cust: Customer) => {
    setSelectedCust(cust);
    setStrategy(null); // Clear previous AI outputs to avoid stale mismatching
  };

  const handleResetCustomer = () => {
    const freshMock: Customer = {
      id: `CUST-SIM-${Math.floor(1000 + Math.random() * 9000)}`,
      name: "Karan Malhotra",
      email: "karan.malhotra@gmail.com",
      gender: "Male",
      seniorCitizen: false,
      partner: false,
      dependents: false,
      tenure: 12,
      phoneService: true,
      multipleLines: "No",
      internetService: "Fiber optic",
      onlineSecurity: "No",
      onlineBackup: "No",
      deviceProtection: "No",
      techSupport: "No",
      streamingTV: "No",
      streamingMovies: "No",
      contract: "Month-to-month",
      paperlessBilling: true,
      paymentMethod: "Electronic check",
      monthlyCharges: 699,
      totalCharges: 8388,
      churn: false
    };
    handleSelectCustomer(freshMock);
  };

  // ----------------------------------------------------
  // SERVER SIDE API DISPATCHES
  // ----------------------------------------------------

  // Fetch AI-powered personalized retention strategy from Express -> Gemini endpoint
  const handleGenerateAIPlaybook = async () => {
    setStrategyLoading(true);
    try {
      const response = await fetch('/api/prediction/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer: selectedCust,
          scoringResult: sandboxScore
        })
      });
      const data = await response.json();
      if (data.success) {
        setStrategy(data.strategy);
      } else {
        console.error('API Fail:', data.error);
      }
    } catch (err) {
      console.error('Network Fail:', err);
    } finally {
      setStrategyLoading(false);
    }
  };

  // Compile general dataset attributes to generate macro segment findings
  const handleGenerateMacroInsights = async () => {
    setMacroLoading(true);
    try {
      const totalChurners = historicalCustomers.filter(c => c.churn).length;
      const totalActive = historicalCustomers.filter(c => !c.churn).length;

      // Count active users with high real-time scores
      const highRiskActiveCount = historicalCustomers.filter(c => {
        if (c.churn) return false;
        return predictCustomerChurn(c).riskCategory === 'High';
      }).length;

      const response = await fetch('/api/prediction/macro-insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          totalChurners,
          totalActive,
          highRiskCount: highRiskActiveCount
        })
      });
      const data = await response.json();
      if (data.success) {
        setMacroInsights(data.insights);
      }
    } catch (err) {
      console.error('Macro Insight error:', err);
    } finally {
      setMacroLoading(false);
    }
  };

  // Trigger macro audit recommendations automatically when cohort tab opens
  useEffect(() => {
    if (activeTab === 'cohort' && !macroInsights) {
      handleGenerateMacroInsights();
    }
  }, [activeTab]);

  // ----------------------------------------------------
  // RECHARTS COHORT COMPUTATIONS
  // ----------------------------------------------------

  const cohortStats = useMemo(() => {
    const total = historicalCustomers.length;
    const churn = historicalCustomers.filter(c => c.churn).length;
    const active = total - churn;
    const churnRate = (churn / total) * 100;

    // Active profiles currently scoring High danger
    const atRiskCurrent = historicalCustomers.filter(c => {
      if (c.churn) return false;
      return predictCustomerChurn(c).riskCategory === 'High';
    }).length;

    const avgPrice = historicalCustomers.reduce((acc, c) => acc + c.monthlyCharges, 0) / total;

    return {
      total,
      churn,
      active,
      churnRate: Number(churnRate.toFixed(1)),
      atRiskCurrent,
      avgPrice: Number(avgPrice.toFixed(0))
    };
  }, []);

  const contractChartData = useMemo(() => {
    const m2m = historicalCustomers.filter(c => c.contract === 'Month-to-month');
    const y1 = historicalCustomers.filter(c => c.contract === 'One year');
    const y2 = historicalCustomers.filter(c => c.contract === 'Two year');

    return [
      {
        name: 'Month-to-Month',
        Total: m2m.length,
        Churned: m2m.filter(c => c.churn).length,
        'Active Clients': m2m.filter(c => !c.churn).length
      },
      {
        name: 'One-year',
        Total: y1.length,
        Churned: y1.filter(c => c.churn).length,
        'Active Clients': y1.filter(c => !c.churn).length
      },
      {
        name: 'Two-year',
        Total: y2.length,
        Churned: y2.filter(c => c.churn).length,
        'Active Clients': y2.filter(c => !c.churn).length
      }
    ];
  }, []);

  const serviceChartData = useMemo(() => {
    const fiber = historicalCustomers.filter(c => c.internetService === 'Fiber optic');
    const dsl = historicalCustomers.filter(c => c.internetService === 'DSL');
    const none = historicalCustomers.filter(c => c.internetService === 'No');

    return [
      {
        name: 'Fiber Optic Plan',
        Active: fiber.filter(c => !c.churn).length,
        Churned: fiber.filter(c => c.churn).length,
      },
      {
        name: 'DSL Copper Plan',
        Active: dsl.filter(c => !c.churn).length,
        Churned: dsl.filter(c => c.churn).length,
      },
      {
        name: 'No Connected Net',
        Active: none.filter(c => !c.churn).length,
        Churned: none.filter(c => c.churn).length,
      }
    ];
  }, []);

  const priceBreakdownChartData = useMemo(() => {
    const loyalCharges = historicalCustomers.filter(c => !c.churn).map(c => c.monthlyCharges);
    const churnCharges = historicalCustomers.filter(c => c.churn).map(c => c.monthlyCharges);

    const avgLoyal = loyalCharges.reduce((a, b) => a + b, 0) / loyalCharges.length;
    const avgChurn = churnCharges.reduce((a, b) => a + b, 0) / churnCharges.length;

    return [
      { name: 'Active loyal accounts', 'Average Monthly Billings (₹)': Number(avgLoyal.toFixed(0)) },
      { name: 'Churned accounts', 'Average Monthly Billings (₹)': Number(avgChurn.toFixed(0)) },
    ];
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-between selection:bg-indigo-100 selection:text-indigo-900 leading-normal">
      
      {/* Universal Page Header Navigation */}
      <header className="bg-white border-b border-slate-200 py-4 px-6 sticky top-0 z-50 shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 text-white rounded-lg shadow-sm">
              <BrainCircuit className="h-6 w-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl font-bold font-display tracking-tight text-slate-900 flex items-center gap-2">
                Customer Churn Intelligence
              </h1>
              <p className="text-xs text-slate-400">
                Classification modeling, dynamic what-if sandbox simulation, and Gemini retention playbooks.
              </p>
            </div>
          </div>

          {/* Module Mode Selector Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button
              onClick={() => setActiveTab('sandbox')}
              className={`flex items-center gap-2 text-xs font-semibold px-4 py-1.5 rounded-md transition-all ${
                activeTab === 'sandbox'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Fingerprint className="h-3.5 w-3.5" />
              Customer Risk Sandbox
            </button>
            <button
              onClick={() => setActiveTab('cohort')}
              className={`flex items-center gap-2 text-xs font-semibold px-4 py-1.5 rounded-md transition-all ${
                activeTab === 'cohort'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <PieChartIcon className="h-3.5 w-3.5" />
              Cohort Threat Intelligence
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Area Layout */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">

        {/* Global Overview Indicators */}
        <section className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <MetricCard
            title="Total Historical Pool"
            value={cohortStats.total}
            subtext="Telco historical records"
            icon={<Users className="h-5 w-5" />}
          />
          <MetricCard
            title="Baseline Churn Rate"
            value={`${cohortStats.churnRate}%`}
            subtext={`${cohortStats.churn} total cancellations`}
            icon={<AlertTriangle className="h-5 w-5 text-rose-500" />}
            trend={{ value: 'Typical Market bounds', isPositive: false }}
          />
          <MetricCard
            title="At-Risk Active Accounts"
            value={cohortStats.atRiskCurrent}
            subtext="Calculated Churn Risk > 65%"
            icon={<Zap className="h-5 w-5 text-amber-500" />}
            trend={{ value: 'Action Needed', isPositive: false }}
          />
          <MetricCard
            title="Average Billing Tier"
            value={`₹${cohortStats.avgPrice}`}
            subtext="Per standard account/month"
            icon={<DollarSign className="h-5 w-5" />}
          />
        </section>

        {/* Dynamic Workflow Routing */}
        {activeTab === 'sandbox' ? (
          /* WORKFLOW 1: SINGLE CUSTOMER ADAPTIVE CLASS TESTING */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Left Frame: Index registry selector */}
            <div className="lg:col-span-5 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold uppercase tracking-wider text-slate-400 font-display flex items-center gap-1.5">
                  <Activity className="h-4 w-4" /> Customer Index Selector
                </h2>
                <span className="text-xs text-slate-400">Click any user to sandbox</span>
              </div>
              <CustomerTable
                customers={historicalCustomers}
                selectedCustomer={selectedCust}
                onSelectCustomer={handleSelectCustomer}
              />
            </div>

            {/* Right Frame: Active Predictor Controls & Sandbox scoring */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Core Scoring Dashboard Card */}
              <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs grid grid-cols-1 md:grid-cols-3 gap-6 relative overflow-hidden">
                <div className="absolute right-0 top-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-2xl" />

                {/* Risk Probability Gage Meter */}
                <div className="flex flex-col items-center justify-center text-center p-3 md:border-r border-slate-100">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono">
                    Churn Probability
                  </span>
                  <div className="text-4xl font-extrabold font-display mt-2 relative">
                    <span className={`${
                      sandboxScore.probability > 0.65 
                        ? 'text-rose-600' 
                        : sandboxScore.probability > 0.3 
                          ? 'text-amber-600' 
                          : 'text-emerald-600'
                    }`}>
                      {Math.round(sandboxScore.probability * 100)}%
                    </span>
                  </div>
                  <span className={`text-[10px] font-bold mt-2 px-2.5 py-0.5 rounded-full ${
                    sandboxScore.probability > 0.65 
                      ? 'bg-rose-50 text-rose-700' 
                      : sandboxScore.probability > 0.3 
                        ? 'bg-amber-50 text-amber-700' 
                        : 'bg-emerald-50 text-emerald-700'
                  }`}>
                    {sandboxScore.riskCategory} Risk
                  </span>
                </div>

                {/* Factor breakdown */}
                <div className="md:col-span-2 space-y-2.5">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider font-mono block">
                    Telemetry Attribution Risk Weights:
                  </span>
                  <div className="space-y-1.5 max-h-[110px] overflow-y-auto pr-1">
                    {sandboxScore.contributingFactors.map((factor, idx) => (
                      <div key={idx} className="flex justify-between items-start text-xs border border-slate-100 p-1.5 rounded bg-slate-50">
                        <div className="flex gap-2">
                          <span className={`font-bold shrink-0 ${
                            factor.impact === 'Positive' ? 'text-rose-500' : 'text-emerald-500'
                          }`}>
                            {factor.impact === 'Positive' ? '▲' : '▼'}
                          </span>
                          <span className="text-slate-700 font-medium">{factor.factor}</span>
                        </div>
                        <span className="text-slate-400 font-mono text-[10px]">
                          {factor.impact === 'Positive' ? '+' : '-'}{(factor.weight * 10).toFixed(0)} score
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Editable What-If simulation slider controllers */}
              <PredictionForm
                customer={selectedCust}
                onChangeCustomer={(updated) => setSelectedCust(updated)}
                onReset={handleResetCustomer}
              />

              {/* Gemini Save Action recommendations playbook */}
              <AIPlaybookSection
                strategy={strategy}
                loading={strategyLoading}
                onGenerate={handleGenerateAIPlaybook}
                customerName={selectedCust.name}
              />
            </div>
          </div>
        ) : (
          /* WORKFLOW 2: DATA SYSTEM THREAT INTELLIGENCE & AUDITS */
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
              <h2 className="text-base font-bold font-display text-slate-800 flex items-center gap-1.5 border-b border-slate-100 pb-3 mb-4">
                <PieChartIcon className="h-5 w-5 text-indigo-500" />
                Global Metric Signatures & Customer Vulnerabilities
              </h2>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* Visual Chart 1: Contract types */}
                <div className="border border-slate-100 rounded-lg p-4 bg-slate-50/50">
                  <span className="text-xs font-semibold text-slate-400 uppercase font-mono tracking-wider block mb-3">
                    Active vs Churned by Contract Format
                  </span>
                  <div className="h-60 w-full text-xs">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={contractChartData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" stroke="#64748b" />
                        <YAxis stroke="#64748b" />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="Active Clients" fill="#6366f1" radius={[4, 4, 0, 0]} />
                        <Bar dataKey="Churned" fill="#fda4af" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2 text-center leading-relaxed">
                    Month-to-month subscribers exhibit high churn rates, representing severe structural churn exposure.
                  </p>
                </div>

                {/* Visual Chart 2: Internet service type breakdown */}
                <div className="border border-slate-100 rounded-lg p-4 bg-slate-50/50">
                  <span className="text-xs font-semibold text-slate-400 uppercase font-mono tracking-wider block mb-3">
                    Churn distribution by Internet Services
                  </span>
                  <div className="h-60 w-full text-xs">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={serviceChartData} layout="vertical">
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                        <XAxis type="number" stroke="#64748b" />
                        <YAxis type="category" dataKey="name" stroke="#64748b" width={80} />
                        <Tooltip />
                        <Legend />
                        <Bar dataKey="Active" fill="#4f46e5" stackId="a" />
                        <Bar dataKey="Churned" fill="#f43f5e" stackId="a" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2 text-center leading-relaxed">
                    Fiber optic connections have higher rates of customer flight, which corresponds with competitive price pressure.
                  </p>
                </div>

                {/* Visual Chart 3: Average charging rates comparison */}
                <div className="border border-slate-100 rounded-lg p-4 bg-slate-50/50">
                  <span className="text-xs font-semibold text-slate-400 uppercase font-mono tracking-wider block mb-3">
                    Monthly Charge fatigue correlation
                  </span>
                  <div className="h-60 w-full text-xs">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={priceBreakdownChartData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" stroke="#64748b" />
                        <YAxis stroke="#64748b" />
                        <Tooltip />
                        <Bar dataKey="Average Monthly Billings (₹)" fill="#06b6d4" radius={[6, 6, 0, 0]}>
                          <Cell fill="#64748b" />
                          <Cell fill="#e11d48" />
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-2 text-center leading-relaxed">
                    Churned customers feature substantially higher average monthly fees compared to retained subscribers.
                  </p>
                </div>

              </div>
            </div>

            {/* Strategic Consultant Gemini Assessment */}
            <div className="bg-slate-900 border border-slate-800 text-slate-150 rounded-xl p-6 shadow-md relative overflow-hidden">
              <div className="absolute right-0 bottom-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 mb-4 gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-gradient-to-br from-indigo-500 to-cyan-500 text-white rounded-lg">
                    <Layers className="h-5 w-5 animate-spin" style={{ animationDuration: '4s' }} />
                  </div>
                  <div>
                    <span className="text-[10px] text-indigo-300 font-bold uppercase tracking-wider font-mono">
                      Corporate Executive Report
                    </span>
                    <h3 className="font-bold text-base text-white font-display">
                      Strategic Customer Vulnerability and Churn Audit
                    </h3>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleGenerateMacroInsights}
                  disabled={macroLoading}
                  className="bg-slate-800 hover:bg-slate-700 py-1.5 px-4 rounded-lg text-xs font-semibold text-indigo-200 hover:text-indigo-100 border border-slate-700 flex items-center gap-1.5 transition-colors shrink-0 disabled:opacity-50"
                >
                  {macroLoading ? (
                    <>
                      <div className="h-3 w-3 border-2 border-slate-500 border-t-white rounded-full animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-3.5 w-3.5" />
                      Refresh Business Report
                    </>
                  )}
                </button>
              </div>

              {macroLoading ? (
                <div className="py-12 flex flex-col items-center justify-center space-y-3">
                  <div className="h-6 w-6 border-2 border-indigo-500 border-t-white rounded-full animate-spin" />
                  <span className="text-xs text-slate-400 font-mono">Recalculating regression coefficients & querying Gemini...</span>
                </div>
              ) : macroInsights ? (
                <div className="text-sm space-y-4 text-slate-300 leading-relaxed font-sans max-w-4xl">
                  {/* Nicely structured response output wrapper */}
                  <div className="prose prose-invert prose-sm">
                    {macroInsights.split('\n\n').map((paragraph, index) => {
                      if (paragraph.startsWith('###')) {
                        return <h4 key={index} className="text-sm font-bold text-white mt-4 font-display font-semibold uppercase tracking-wider border-b border-slate-800 pb-1">{paragraph.replace('###', '').trim()}</h4>;
                      } else if (paragraph.startsWith('**')) {
                        const parts = paragraph.split('**');
                        return (
                          <div key={index} className="mt-2 text-xs">
                            <strong className="text-white font-semibold block sm:inline">{parts[1]}</strong>
                            <span className="text-slate-300">{parts.slice(2).join('')}</span>
                          </div>
                        );
                      }
                      return <p key={index} className="text-xs text-slate-400">{paragraph}</p>;
                    })}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <span className="text-xs text-slate-500">Audit details compiling. Click Refresh to manually trigger.</span>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Humble Aesthetic Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-6 mt-12 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-3">
          <span>Customer Churn Predictor • Designed with Swiss Typography and Tailwind CSS</span>
          <div className="flex gap-4 font-mono text-[10px]">
            <span>Model: Logistic Classify • cal_v1.0</span>
            <span>LLM: Gemini-3.5-Flash</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
